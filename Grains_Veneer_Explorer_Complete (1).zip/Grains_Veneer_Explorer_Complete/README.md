# GRAINS VENEERS INDUSTRIES — Material Explorer

A static, Vercel-ready veneer catalogue and visual preview app.

## Collections
- Hybrid Veneer: 15 cleaned board photographs from the supplied PDF. EX-102 is intentionally omitted. The two source photographs labelled EX-109 are retained separately (source pages 4 and 7).
- Textured Veneer: category placeholder; product photos/catalogue not supplied yet.
- Printed Veneer: 20 artwork/design pages from the supplied PRINTED DESIGN PDF. PV-01 to PV-20 are Explorer reference IDs, not confirmed manufacturer codes. The source reference A-2588-2 is retained on PV-19.

## Features
- Search by code, name, and source reference
- Tone/style filter
- Favourites saved in the current browser
- Compare up to four products
- Quick view and WhatsApp enquiry
- Try in Space: upload a room/furniture photo, select a veneer, drag and resize the overlay, adjust opacity, and save the preview

## Run locally
Simply open `index.html` in a modern browser. Keep the `assets` folder beside it.

## Deploy to Vercel
Import the GitHub repository in Vercel. Choose **Other** as framework preset. Leave Build Command and Output Directory empty (or use the static site defaults); the root `index.html` and `assets/` folder are served directly.

## Important
The Try in Space feature is a manual visual mock-up, not automatic perspective mapping or print colour proof. Screen colour may differ from physical veneer samples.
