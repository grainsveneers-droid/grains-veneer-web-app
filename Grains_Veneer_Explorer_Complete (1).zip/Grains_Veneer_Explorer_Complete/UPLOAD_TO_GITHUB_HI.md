# GitHub + Vercel par upload karne ke steps (Windows)

## Sabse pehle backup
1. GitHub repository ka current `index.html` backup ke liye apne PC par alag save kar lo.
2. Live site ko tab tak change mat karo jab tak naya project local preview mein check na kar lo.

## GitHub Desktop se upload (recommended)
1. GitHub Desktop install/open karo: https://desktop.github.com/
2. Apne GitHub account se sign in karo.
3. `File > Clone repository` select karo.
4. `grainsveneers-droid/grains-veneer-web-app` repository choose karke local PC par clone karo.
5. Is ZIP ko `Extract All` karo.
6. Extracted `Grains_Veneer_Explorer_Complete` folder ke andar ki saari cheezein (folder ko khud nahi) cloned repository folder mein copy karo.
7. Agar Windows pooche to old `index.html` ko replace karo. `assets` folder copy hone par uske andar `hybrid` aur `printed` subfolders rehne chahiye.
8. GitHub Desktop mein changed files dikhenge. Summary mein `Replace with Grains Veneer Explorer` likho.
9. `Commit to main` click karo, phir `Push origin` click karo.
10. Vercel connected hai to naya deployment automatically start hona chahiye. Vercel Deployments tab mein status `Ready` hone ke baad site refresh karo.

## Repository ka sahi final structure

```text
repository-root/
  index.html
  vercel.json
  README.md
  UPLOAD_TO_GITHUB_HI.md
  assets/
    hybrid/
      EX-101_p14.jpg
      ...
    printed/
      PV-01_page01.jpg
      ...
```

## Vercel settings
- Framework Preset: `Other`
- Root Directory: repository root (`.`)
- Build Command: blank / no build command
- Output Directory: blank / default

Ye static HTML app hai. `index.html` ko `assets` folder se alag upload mat karna.
